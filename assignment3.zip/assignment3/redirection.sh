echo "Hello World!" > input.txt
ls > input2.txt
meow > input3.txt
pwd > input4.txt