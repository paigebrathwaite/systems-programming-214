cd 1
cd 2/3
cd 4
cd 4
cd ..
pwd
cd ../..
pwd
cd ..
pwd
which ls
which gcc
which doesn'texist
pwd 31
cd 9896
cd hello